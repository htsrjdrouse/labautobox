<? session_start(); ?>




<? if(isset($_POST['upload'])){
$target_dir = "uploads/";
$target_file =  $target_dir . basename($_FILES["fileToUpload"]["name"]);

$uploadOk = 1;
$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);

if($check == false) {
  $uploadOk = 1;
} else {
  echo "File is an image.";
  $uploadOk = 1;
}

if ($_FILES["fileToUpload"]["size"] > 5000000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

  if ($uploadOk == 1){
   if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
      //$msg = 'target file '.$target_file.' uploaded<br>';
  } else {
      $msg = "Sorry, there was an error uploading your file.<br>";
  }
  }
}
?>


<? //header("Refresh:0");?>
<!DOCTYPE html>
<html lang="en">
<head>
<? //include('functionslib.php');?>
<? error_reporting(E_ALL & ~E_NOTICE);?>
<title>HTS LabBot</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/bootstrap.min.css">
  <script src="/jquery.min.js"></script>
  <script src="/bootstrap.min.js"></script>

</head>

<div class="row">
 <div class="col-md-1"></div>
 <div class="col-md-4"><br><br>
  <h3>Upload STL</h3>


  </div>
 <div class="col-md-6"><br><br>
 </div>
</div>
<div class="row">
 <div class="col-md-1"></div>
 <div class="col-md-4"><br> 

<h4>Select object list file:</h4><br>
 <?$dir = scandir("uploads/"); ?>
 <? $size = count($dir)-2;
  if (count($dir) > 10){ $size=10; }
 ?>
<? array_shift($dir)?>
<? array_shift($dir)?>
<form action=objects.json.form.php method=post>
 <select class="form-control form-control-sm" name="objectlist" size=<?=$size?>>
  <? foreach($dir as $key => &$val){ ?>
  <? if ($val == $_SESSION['objectsactive']) { ?> 
   <option value=<?=$key?> selected><?=$val?></option>
  <? } else { ?>
   <option value=<?=$key?>><?=$val?></option>
  <? } ?>
  <? } ?>
 </select>
<br>
  <button type="submit" name="select" class="btn-sm btn-primary">Select file</button><br><br>
  <button type="submit" name="display" class="btn-sm btn-success">Display</button><br><br>
  <button type="submit" name="delete" class="btn-sm btn-danger">Delete file</button><br><br>
</form>

 </div>
 <div class="col-md-1"><br><br>
<form action="objects.json.php" method="post" enctype="multipart/form-data">
 <style>


.fileContainer {
    overflow: hidden;
    position: relative;
}

.fileContainer [type=file] {
    cursor: inherit;
    display: block;
    font-size: 999px;
    filter: alpha(opacity=0);
    min-height: 100%;
    min-width: 100%;
    opacity: 0;
    position: absolute;
    right: 0;
    text-align: right;
    top: 0;
}
 </style>

</div>

 <div class="col-md-1">

<script>
    updateList = function() {
    var input = document.getElementById('fileToUpload');
    var output = document.getElementById('fileList');
    var children = "";
    for (var i = 0; i < input.files.length; ++i) {
        children += '<li>' + input.files.item(i).name + '</li>';
    }
    output.innerHTML = '<ul>'+children+'</ul>';
}
</script>
<script>
function getFile() {
  document.getElementById("upfile").click();
}

function sub(obj) {
  var file = obj.value;
  var fileName = file.split("\\");
  document.getElementById("yourBtn").innerHTML = fileName[fileName.length - 1];
  document.myForm.submit();
  event.preventDefault();
}
</script>
<style>
#yourBtn {
  position: relative;
  /*top: 50px;*/
  font-family: calibri;
  width: 150px;
  padding: 10px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border: 1px dashed #BBB;
  text-align: center;
  background-color: #FF8C00;
  color: white;
  cursor: pointer;
}
</style>

<h4>Upload STL file</h4>


<br>
  <div id="yourBtn" onclick="getFile()">Click to upload STL</div>
  <!-- this is your file input tag, so i hide it!-->
  <!-- i used the onchange event to fire the form submission-->
  <div style='height: 0px;width: 0px; overflow:hidden;'><input id="upfile" type="file" name="fileToUpload" value="upload" onchange="sub(this)" /></div>

  <button type="submit" name=upload value="Upload file" class="btn btn-primary">Upload file</button>
<br>
</form>
</div>
<div class="col-md-3"><?=$msg?></div>
</div>

<div class="row">
 <div class="col-md-1"><br><br></div>
 <div class="col-md-2">


</div>
 <div class="col-md-3"></dir>
</div>

</body>
</html>
