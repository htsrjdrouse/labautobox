<? session_start(); ?>
<? include('blabber.inc.php');?>
<? include('tcaro.php'); ?>

<?

//include('uCP4.1.lineitems.php');
?>
 <?php //include('bbs.navlist.php'); ?>

Objects <? echo $_SESSION['objectsactive'];?><br>


<?
//var_dump($lineitems);

 $pid = "vvv.jscad";
 //$pid = "silicon_master_10um_quadrant.jscad";
 //$dir = "/3dviewer/cellprom/recenter.";
 $dir = "/3dviewer/cellprom/";
 $id = $dir.$pid;

include('ddiver.3dviewer.php'); 

?>
